import { get_bmi_category, calculate_bmi} from "./knowledge/knowledge.ts";

export { get_bmi_category, calculate_bmi };
